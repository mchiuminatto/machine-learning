import pandas as pd
from trading_lib.features.abstract import Feature


class MovingAverageFeatures(Feature):
    def __init__(self,
                 periods: int,
                 source_column: str,
                 lag_periods: int,
                 delta_periods: int = 1
                 ):
        self.periods: int = periods
        self.source_column: str = source_column

        super().__init__(lag_periods=lag_periods, delta_periods=delta_periods)

    def calculate_ma(self, price: pd.DataFrame):
        column_name = f"ma-{self.periods}"
        price[column_name] = price[self.source_column].rolling(self.periods).mean()
        self.features.append(column_name)
        price = self.calculate_lagged_columns(price, column_name)
        return price

    def calculate_delta_ma(self, price: pd.DataFrame) -> pd.DataFrame:
        source_column = f"ma-{self.periods}"
        price = self.calculate_delta(price, source_column)
        price = self.calculate_lagged_columns(price, self.features[-1])

        return price

    def compute(self, price: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        price = self.calculate_ma(price)
        price = self.calculate_delta(price, f"ma-{self.periods}")
        return price
