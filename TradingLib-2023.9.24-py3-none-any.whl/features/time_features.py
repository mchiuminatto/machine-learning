import pandas as pd

from trading_lib.features.abstract import Feature

class TimeFeatures(Feature):
    def __init__(self):
        super().__init__()

    def compute(self, dataset: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        dataset["week"] = dataset.index.isocalendar().week
        dataset["month"] = dataset.index.month
        dataset["day-of-month"] = dataset.index.day
        dataset["day-of-week"] = dataset.index.weekday
        dataset["hour"] = dataset.index.time

        self.features = ["week", "month", "day-of-month", "day-of-week", "hour"]

        return dataset

    def _calculate_lags(self, price: pd.DataFrame, column_mame: str) -> pd.DataFrame:
        return price

