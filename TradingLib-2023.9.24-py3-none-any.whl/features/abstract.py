import abc
import pandas as pd
from pandas import DataFrame


class Feature(abc.ABC):

    def __init__(self, *args, **kwargs):
        self.features: list[str] = []
        self.lag_periods: int | None = kwargs.get("lag_periods", None)
        self.delta_periods: int = kwargs.get("delta_periods", 1)

    @abc.abstractmethod
    def compute(self, dataset: DataFrame, *args, **kwargs) -> DataFrame:
        ...

    def calculate_lagged_columns(self, price: DataFrame, column_name: str) -> DataFrame:
        if self.lag_periods is None:
            raise ValueError("To calculate lagged columns you need to specify lag_periods in the constructor")
        lagged = pd.concat(
            [price[column_name].shift(lag).rename(f"{column_name}_t0-{lag}")
             for lag in range(1, self.lag_periods)], axis=1)
        self.features.extend(lagged.columns)
        price = pd.concat([price, lagged], axis=1)
        price.dropna(inplace=True)
        return price

    def calculate_delta(self, price: DataFrame, column: str) -> DataFrame:
        column_name = f"delta_{column}-{self.delta_periods}"
        price[column_name] = price[column] - price[column].shift(self.delta_periods)
        self.features.append(column_name)
        return price
