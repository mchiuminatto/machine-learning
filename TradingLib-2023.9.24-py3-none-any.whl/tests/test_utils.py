import pandas as pd
import numpy as np

def build_price_time_series() -> pd.DataFrame:
    date_index = pd.DatetimeIndex(pd.date_range("2020-01-01", "2023-06-01", freq="4h"))
    price_values = np.random.normal(1.1300, 0.0010, len(date_index))
    price = pd.DataFrame({"date-time": date_index, "Close": price_values})
    price.set_index("date-time", inplace=True)
    return price
