from pandas import DataFrame
import random
from trading_lib.features.abstract import Feature
from tests.test_utils import build_price_time_series


class SimulateFeature(Feature):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def compute(self, dataset: DataFrame, *args, **kwargs) -> DataFrame:
        return dataset


class TestAbstracts:

    def test_instantiation(self):
        features = SimulateFeature(lag_periods=20)
        assert features.lag_periods == 20

    def test_feature_lagging(self):
        price = build_price_time_series()
        features = SimulateFeature(lag_periods=20)
        price = features.calculate_lagged_columns(price, "Close")
        for column in price.columns:
            if column == "Close":
                continue
            lag = int(column.split("-")[1])
            assert price[column][-1] == price["Close"].shift(lag)[-1]

    def test_feature_delta(self):
        price = build_price_time_series()
        delta_periods = random.randint(1, 10)
        features = SimulateFeature(delta_periods=delta_periods)
        price["delta"] = features.calculate_delta(price["Close"])
        price["deta_crosscheck"] = price["Close"] - price["Close"].shift(delta_periods)

        assert (price["deta_crosscheck"] - price["delta"]).sum() == 0
