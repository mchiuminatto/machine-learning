from trading_lib.features.keltner_channel import KeltnerChannel
from talib import MA_Type
import talib as ta
from trading_lib import constants
from trading_lib.utils.dataset_management import open_csv
LOOK_BACK = 14
TEST_FILE_NAME = constants.ROOT_FOLDER + "/tests/data/EURUSD_5 Mins_Ask_2023.01.01_2023.04.26.csv"


class TestKeltner:

    def test_calculate_keltner(self):
        multiplier: float = 1
        keltner = KeltnerChannel(LOOK_BACK, multiplier,MA_Type.SMA)
        price = open_csv(TEST_FILE_NAME,
                             "Time (America/Buenos_Aires)",
                         drop_cols=False)
        keltner.compute(price["High"], price["Low"], price["Close"])
        atr = ta.ATR(price["High"], price["Low"], price["Close"], LOOK_BACK)
        assert (keltner.upper_line - keltner.lower_line - 2*atr).sum().round(5) == 0

    # TODO: Test multipliers
