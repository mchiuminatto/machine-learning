import numpy as np
from trading_lib.features.ma_features import MovingAverageFeatures
from tests.test_utils import build_price_time_series


class TestMAFeatures:

    def test_ma_calculation(self):
        ma_features = MovingAverageFeatures(5,
                                            "Close",
                                            lag_periods=100,
                                            delta_periods=100)
        price = build_price_time_series()
        price["ma-Close-5"] = ma_features.calculate_ma(price["Close"])
        price["cross_check"] = (price["Close"] +
                                price["Close"].shift(1) +
                                price["Close"].shift(2) +
                                price["Close"].shift(3) +
                                price["Close"].shift(4)
                                ) / 5
        price.dropna(inplace=True)
        assert np.abs((price["cross_check"].round(7) - price["ma-Close-5"]).sum().round(7)) <= 10e-5

    def test_full_calculation(self):
        ma_features = MovingAverageFeatures(5,
                                            "Close",
                                            lag_periods=100,
                                            delta_periods=100)
        price = build_price_time_series()
        price = ma_features.compute(price)
        price["cross_check"] = (price["Close"] +
                                price["Close"].shift(1) +
                                price["Close"].shift(2) +
                                price["Close"].shift(3) +
                                price["Close"].shift(4)
                                ) / 5
        price.dropna(inplace=True)
        assert np.abs((price["cross_check"].round(7) - price["ma-Close-5"]).sum().round(7)) <= 10e-5