from trading_lib.features.time_features import TimeFeatures
from trading_lib.utils.dataset_management import open_csv
import trading_lib.constants as constants

TEST_FILE_NAME = constants.ROOT_FOLDER + "/tests/data/EURUSD_5 Mins_Ask_2023.01.01_2023.04.26.csv"

class TestTimeFeatures:

    def test_time_features(self):
        price = open_csv(TEST_FILE_NAME,
                             "Time (America/Buenos_Aires)",
                         drop_cols=False)
        time_features = TimeFeatures()
        time_features.compute(price)

