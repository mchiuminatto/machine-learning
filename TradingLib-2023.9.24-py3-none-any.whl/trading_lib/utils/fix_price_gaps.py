import abc
from enum import Enum
from abc import ABC

import pandas as pd


class FixMethod(Enum):
    FORWARD_FILL = "FORWARD_FILL",
    BACKWARD_FILL = "BACKWARD_FILL",
    SYNTHETIC = "SYNTH"


class FixPriceFactory:

    def __init__(self, fix_method: FixMethod):
        self.fix_method: FixMethod = fix_method

    def get_fixer(self):
        if self.fix_method == FixMethod.FORWARD_FILL:
            return ForwardFillInterpolation()
        if self.fix_method == FixMethod.BACKWARD_FILL:
            return ForwardFillInterpolation()


class PriceGapFixer(ABC):
    @staticmethod
    @abc.abstractmethod
    def compute(time_series: pd.DataFrame, gaps_to_fix: pd.DataFrame) -> pd.DataFrame:
        ...


class ForwardFillInterpolation(PriceGapFixer):

    @staticmethod
    def compute(time_series: pd.DataFrame, gaps_to_fix: pd.DataFrame):

        freq_table_raw = time_series["delta"].value_counts()
        max_x = freq_table_raw.argmax()
        delta_max = freq_table_raw.index[max_x]
        for row in gaps_to_fix.iterrows():
            end_gap_date = row[1]["current_date"]
            start_gap_date = row[1]["prev_date"]
            mask_gap = (time_series.index >= start_gap_date) & (time_series.index <= end_gap_date)
            price_resample = time_series[mask_gap].resample(delta_max).ffill()
            time_series = pd.concat([time_series, price_resample[1:-1]])
        time_series.sort_values(by="date-time", inplace=True)
        return time_series


class BackwardFillInterpolation(PriceGapFixer):
    @staticmethod
    def compute(time_series: pd.DataFrame, gaps_to_fix: pd.DataFrame):
        time_series["delta"] = time_series.index.to_series().diff()
        time_series["temp-date"] = time_series.index
        time_series["prev-date"] = time_series["temp-date"].shift(1)
        time_series.dropna(inplace=True)
        time_series["day_of_week"] = time_series.index.day_of_week
        freq_table_raw = time_series["delta"].value_counts()
        max_x = freq_table_raw.argmax()
        delta_max = freq_table_raw.index[max_x]
        for row in gaps_to_fix.iterrows():
            end_gap_date = row[1]["temp-date"]
            start_gap_date = row[1]["prev-date"]
            mask_gap = (time_series.index >= start_gap_date) & (time_series.index <= end_gap_date)
            price_resample = time_series[mask_gap].resample(delta_max).bfill()
            time_series = pd.concat([time_series, price_resample[1:-1]])
        time_series.sort_values(by="date-time", inplace=True)
        return time_series
