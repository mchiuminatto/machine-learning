import logging
import pandas as pd


class MissingPeriodsChecks:
    def __init__(self, ignore_weekends: bool = False):
        self.max_frequency_index: any = None
        self.max_frequency_index_value: any = None
        self.max_frequency: int = 0
        self.max_occurrences_percentage: float = 0.0
        self.total_occurrences: int = 0

        self.ignore_weekends: bool = ignore_weekends

    def compute(self, time_series: pd.DataFrame) -> pd.DataFrame:

        time_series["delta"] = time_series.index.to_series().diff()
        time_series["current_date"] = time_series.index
        time_series["prev_date"] = time_series["current_date"].shift(1)
        freq_table_raw = time_series["delta"].value_counts()

        self.max_frequency_index = freq_table_raw.argmax()
        self.max_frequency_index_value = freq_table_raw.index[self.max_frequency_index]
        self.max_frequency = freq_table_raw.iloc[self.max_frequency_index].astype(int)
        self.total_occurrences = freq_table_raw.sum()
        self.max_occurrences_percentage = (100 * self.max_frequency / self.total_occurrences).round(3)

        if self.ignore_weekends:
            time_series["day_of_week"] = time_series.index.day_of_week
            missing_filter = (time_series["delta"] > self.max_frequency_index_value) & \
                             (time_series["day_of_week"] != 6)
        else:
            missing_filter = time_series["delta"] != self.max_frequency_index_value

        if len(time_series[missing_filter]) > 0:
            logging.warning("Found discontinuity periods")
            logging.warning(time_series[missing_filter])
        else:
            logging.info("No discontinuity time found")

        return time_series[missing_filter]



