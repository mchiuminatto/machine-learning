import pandas as pd
import dask
from dask import dataframe as dd


def open_csv(file_name: str, date_time_column_name: str, drop_cols=True) -> dd:
    dataset = dd.read_csv(f"{file_name}")
    dataset = dataset.rename(columns={date_time_column_name: "date-time"})
    dataset["date-time"] = dd.to_datetime(dataset["date-time"])
    dataset = dataset.set_index("date-time")
    if drop_cols:
        dataset = dataset.drop(columns=["Open", "High", "Low", "Volume "])
    return dataset


def save_parquet(file_name: str, dataset: dd):
    dd.to_parquet(dataset, file_name)


def open_parquet(file_name: str) -> dd:
    return dd.read_parquet(file_name)
