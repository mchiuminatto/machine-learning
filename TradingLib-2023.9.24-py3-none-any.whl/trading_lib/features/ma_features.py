import pandas as pd
import talib
from trading_lib.features.abstract import Feature


class MovingAverageFeatures(Feature):
    def __init__(self,
                 periods: int,
                 source_column: str,
                 lag_periods: int,
                 delta_periods: int = 1,
                 include_lagged_columns: bool=True,
                 ma_type: talib.MA_Type = talib.MA_Type.SMA
                 ):
        self.periods: int = periods
        self.source_column: str = source_column
        self.ma_type = ma_type
        self.include_lagged_columns = include_lagged_columns

        super().__init__(lag_periods=lag_periods, delta_periods=delta_periods)

    def calculate_ma(self, price: pd.Series):
        ma = talib.MA(price, self.periods, matype=self.ma_type)
        return ma

    def compute(self, price: pd.DataFrame, *args, **kwargs) -> pd.DataFrame:
        """
        Helper to calculate multiple ma related features
        :param price: Price dataset
        :param args:
        :param kwargs:
        :return:
        """
        ma_column_name = f"ma-{self.source_column}-{self.periods}"
        price[ma_column_name] = self.calculate_ma(price[self.source_column])

        delta_ma_column_name = f"delta-{ma_column_name}-{self.delta_periods}"
        price[delta_ma_column_name] = self.calculate_delta(price[ma_column_name])

        if self.include_lagged_columns:
            price = self.calculate_lagged_columns(price, ma_column_name)
            price = self.calculate_lagged_columns(price, delta_ma_column_name)

        return price
