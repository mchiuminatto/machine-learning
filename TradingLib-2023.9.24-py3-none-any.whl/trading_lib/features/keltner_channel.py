import pandas as pd
import talib as ta
from talib import MA_Type

from trading_lib.features.abstract import Feature


class KeltnerChannel(Feature):

    def __init__(self, periods: int, multiplier: float, ma_type: MA_Type):
        self.periods: int = periods
        self.multiplier: float = multiplier
        self.ma_type: MA_Type = ma_type
        self.upper_line: pd.Series | None = None
        self.lower_line: pd.Series | None = None
        self.ma: pd.Series | None = None
        self.atr: pd.Series | None = None

        super().__init__()

    def compute(self,
                high: pd.Series,
                low: pd.Series,
                close: pd.Series
                ) -> (pd.Series, pd.Series, pd.Series, pd.Series):
        self.atr = ta.ATR(high, low, close, self.periods)
        self.ma = ta.MA(close, self.periods, self.ma_type)
        self.upper_line = self.ma + self.multiplier * self.atr
        self.lower_line = self.ma - self.multiplier * self.atr
        return self.upper_line, self.lower_line, self.ma, self.atr
