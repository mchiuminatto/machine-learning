import abc
import pandas as pd
from pandas import DataFrame
from pandas import Series


class Feature(abc.ABC):

    def __init__(self, *args, **kwargs):
        self.features: list[str] = []
        self.lag_periods: int | None = kwargs.get("lag_periods", None)
        self.delta_periods: int | None = kwargs.get("delta_periods", 1)

    @abc.abstractmethod
    def compute(self, *args, **kwargs) -> Series | DataFrame | tuple:
        ...

    def calculate_lagged_columns(self, price: DataFrame, column_name: str) -> DataFrame:
        if self.lag_periods is None:
            raise ValueError("To calculate lagged columns you need to specify lag_periods in the constructor")
        lagged = pd.concat(
            [price[column_name].shift(lag).rename(f"{column_name}_t0-{lag}")
             for lag in range(1, self.lag_periods)], axis=1)
        self.features.extend(lagged.columns)
        price = pd.concat([price, lagged], axis=1)
        price.dropna(inplace=True)
        return price

    def calculate_delta(self, price: Series) -> Series:
        delta = price - price.shift(self.delta_periods)
        return delta
