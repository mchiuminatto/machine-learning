import pandas as pd
import numpy as np
from abc import ABC
from enum import Enum


class MAEstimatorType(Enum):
    NOISELESS = "Noiseless"
    GAUSSIAN_NOISE = "Gaussian"
    ADAPTIVE_GAUSSIAN = "AdaptiveGaussian"
    NAIVE = "Naive"


class MAEstimator(ABC):

    def __init__(self, ma_column: str,
                 pip_decimal_position: int,
                 noise_scale_pip: float,
                 standard_dev_periods: int = 0):
        self.ma_column: str = ma_column
        self.pip_decimal_position: int = pip_decimal_position
        self.noise_scale_pip: float = noise_scale_pip
        self.pip_to_decimal_factor = 1 / (10 ** self.pip_decimal_position)
        self.noise_scale_points: float = self.noise_scale_pip * self.pip_to_decimal_factor
        self.standard_dev_periods = standard_dev_periods

    def compute(self, price: pd.DataFrame) -> pd.DataFrame:
        ...


class MAEstimatorFactory:

    def get_ma_estimator(self,
                         estimator_type: MAEstimatorType,
                         ma_column: str,
                         pip_decimal_position: int,
                         noise_scale_pip: float,
                         standard_dev_periods: int | None = None) -> MAEstimator:

        if estimator_type == MAEstimatorType.NOISELESS:
            return MANoiseless(ma_column,
                               pip_decimal_position,
                               noise_scale_pip)
        elif estimator_type == MAEstimatorType.GAUSSIAN_NOISE:
            return MAGaussian(ma_column,
                              pip_decimal_position,
                              noise_scale_pip)
        elif estimator_type == MAEstimatorType.ADAPTIVE_GAUSSIAN:
            return MAGaussianAdaptive(ma_column, pip_decimal_position,
                                      noise_scale_pip,
                                      standard_dev_periods=standard_dev_periods)
        elif estimator_type == MAEstimatorType.NAIVE:
            return MANaive(ma_column, pip_decimal_position, noise_scale_pip)


class MANoiseless(MAEstimator):

    def compute(self, price: pd.DataFrame) -> pd.DataFrame:
        price["ma_i+1"] = price[self.ma_column].shift(-1)
        price["noise"] = 0
        price["MA_i+1"] = price["ma_i+1"] + price["noise"]
        return price


class MAGaussian(MAEstimator):

    def compute(self, price) -> pd.DataFrame:
        price["ma_i+1"] = price[self.ma_column].shift(-1)
        price["noise"] = np.random.normal(0, self.noise_scale_points, len(price))
        price["MA_i+1"] = price["ma_i+1"] + price["noise"].round(self.pip_decimal_position + 1)

        return price


class MAGaussianAdaptive(MAEstimator):

    @staticmethod
    def generate_noise(row):
        noise = np.random.normal(0, row)
        return noise

    def compute(self, price) -> pd.DataFrame:
        price["ma_i+1"] = price[self.ma_column].shift(-1)
        price["ma_i+1_std"] = price["ma_i+1"].rolling(self.standard_dev_periods).std()
        price["noise"] = price["ma_i+1_std"].apply(self.generate_noise)
        price["MA_i+1"] = price["ma_i+1"] + price["noise"]

        return price


class MANaive(MAEstimator):
    def compute(self, price) -> pd.DataFrame:
        price["ma_i+1"] = price[self.ma_column].shift(-1)
        price["dMA"] = price[self.ma_column] - price[self.ma_column].shift(1)
        price["MA_i+1"] = price[self.ma_column] + price["dMA"]
        price["noise"] = price["MA_i+1"] - price["ma_i+1"]

        return price

